  <div id="blue">
    <div class="container">
      <div class="row centered">
        <div class="col-lg-8 col-lg-offset-2">
          <h4>NOTRE ÉQUIPE</h4>
          <p>ON EST COOL!</p>
        </div>
      </div>
      <!-- row -->
    </div>
    <!-- container -->
  </div>
  <!--  bluewrap -->


  <div class="container w">
    <div class="row centered">
      <br><br>
      <div class="col-lg-3">
        <img class="img-circle" src="img/pic.jpg" width="110" height="110" alt="">
        <h4>Homer Simpson</h4>
        <p>C'est pas parce que je m'en fous que je comprends pas.</p>
        <p><a href="index.php?page=membres.php&id=1">@Homer</a></p>
      </div>
      <!-- col-lg-3 -->

      <div class="col-lg-3">
        <img class="img-circle" src="img/pic2.jpg" width="110" height="110" alt="">
        <h4>Marge Simpson</h4>
        <p>Quand une femme dit que tout va bien, ça veut dire que tout va mal.</p>
        <p><a href="index.php?page=membres.php&id=2">@Marge</a></p>
      </div>
      <!-- col-lg-3 -->

      <div class="col-lg-3">
        <img class="img-circle" src="img/pic3.jpg" width="110" height="110" alt="">
        <h4>Montgomery Burns</h4>
        <p>Famille, religion, amitié. Voici les 3 démons que vous devez abattre pour réussir dans les affaires.</p>
        <p><a href="#">@Mark_BlackTie</a></p>
      </div>
      <!-- col-lg-3 -->

      <div class="col-lg-3">
        <img class="img-circle" src="img/pic4.jpg" width="110" height="110" alt="">
        <h4>Moe Szyslak</h4>
        <p>On pourrait vendre de l'alcool. Je fais ça très bien.</p>
        <p><a href="#">@Moe</a></p>
      </div>
      <!-- col-lg-3 -->

    </div>
    <!-- row -->
    <br>
    <br>
  </div>
  <!-- container -->


  <!-- PORTFOLIO SECTION -->
  <div id="dg">
    <div class="container">
      <div class="row centered">
        <h4>NOS COMPETENCES</h4>
        <br>

        <!-- First Chart -->
        <div class="col-lg-3">
          <canvas id="canvas" height="130" width="130"></canvas>
          <br>
          <p><b>Design</b></p>
          <p><small>Marge dessine super bien.</small></p>
        </div>
        <!-- /col-lg-3 -->

        <!-- Second Chart -->
        <div class="col-lg-3">
          <canvas id="canvas2" height="130" width="130"></canvas>
          <br>
          <p><b>Developement WEB</b></p>
          <p><small>Nous sommes super compétent en sécurité de nos site web.</small></p>
        </div>
        <!-- /col-lg-3 -->

        <!-- Third Chart -->
        <div class="col-lg-3">
          <canvas id="canvas3" height="130" width="130"></canvas>
          <br>
          <p><b>SEO</b></p>
          <p><small>La meilleure des communications est assurée par Mr.Burns.</small></p>
        </div>
        <!-- /col-lg-3 -->

        <!-- Fourth Chart -->
        <div class="col-lg-3">
          <canvas id="canvas4" height="130" width="130"></canvas>
          <br>
          <p><b>Sécrurité</b></p>
          <p><small>Toutes nos applications sont incassables.</small></p>
        </div>
        <!-- /col-lg-3 -->


      </div>
      <!-- row -->
    </div>
    <!-- container -->
  </div>
  <!-- DG -->

  <!-- FOOTER -->
  <div id="f">
    <div class="container">
      <div class="row centered">
        <a href="#"><i class="fa fa-twitter"></i></a><a href="#"><i class="fa fa-facebook"></i></a><a href="#"><i class="fa fa-dribbble"></i></a>

      </div>
      <!-- row -->
    </div>
    <!-- container -->
  </div>
  <!-- Footer -->


