# Simpson Vulnerable Web site !

## Introduction

Just would like to share a little work of me, a simple vulnerable website about simpson.
All the website is in French, sorry for others but too lazy to translate it :P

## How to setup

Simply import noob.sql, change login to "root" and no password (Yes I love informatic security ;) )


## Vulnerabilies to find

* XSS
* Weak cypher
* SQLi 1
* SQLi 2
* CSRF
* LFI


## Credits
Thanks for downloading this template!

Template Name: Spot
Template URL: https://templatemag.com/spot-bootstrap-freelance-template/
Author: TemplateMag.com
License: https://templatemag.com/license/